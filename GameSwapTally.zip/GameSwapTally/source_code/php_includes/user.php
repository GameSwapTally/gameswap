<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $u; ?>Profile - GameSwapTally</title>
<link rel="stylesheet" type="text/css" href="css/form.css">
<link rel="stylesheet" type="text/css" href="css/general.css">
<link rel="icon" type="image/png" href="asset/favicon.png">
<script src="js/main.js"></script>
<script src="js/ajax.js"></script>
</head>

<body>

		<div class="wrapper">
			<div class="Header">
				<div id="left0">
					<a href="index.html"><img src="logo.png" alt="GameSwapTally" id="homeLogo"></img></a>
				</div>
				<div id="right0">
					<a href="https://www.cs.fsu.edu/"><img src="asset/fsu1.png" 
						onmouseover="this.src='asset/fsu2.png'" height="50" width="50"/></a>
					<a href="https://github.com/GameSwapTally/gameswap"><img src="asset/Github1.png" 
						onmouseover="this.src='asset/Github2.png'" height="50" width="50"/></a>
				</div>
			</div> <!-- end Header -->
					
<form method="post" enctype="multipart/form-data" id="userForm" width="100%">
<div align="center">
	<?php
		include_once("php_includes/check_login_status.php");
		$db_conx = mysqli_connect("localhost", "root", "meat", "gameswaptally");
		// Initialize any variables that the page might echo
		$u = "";
		$sex = "Male";
		$userlevel = "";
		$country = "";
		$joindate = "";
		$lastsession = "";
		// Make sure the _GET username is set, and sanitize it
		if(isset($_GET["u"])){
			$u = preg_replace('#[^a-z0-9]#i', '', $_GET['u']);
		} else {
			header("location: index.html");
			exit();	
		}
		// Select the member from the users table
		$sql = "SELECT * FROM users WHERE username='$u' AND activated='1' LIMIT 1";
		$user_query = mysqli_query($db_conx, $sql);
		// Now make sure that user exists in the table
		$numrows = mysqli_num_rows($user_query);
		if($numrows < 1){
			echo "That user does not exist or is not yet activated, press back";
			exit();	
		}
		// Check to see if the viewer is the account owner
		$isOwner = "no";
		if($u == $log_username && $user_ok == true){
			$isOwner = "yes";
		}
		// Fetch the user row from the query above
		while ($row = mysqli_fetch_array($user_query, MYSQLI_ASSOC)) {
			$profile_id = $row["id"];
			$signup = $row["signup"];
			$lastlogin = $row["lastlogin"];
			$joindate = strftime("%b %d, %Y", strtotime($signup));
			$lastsession = strftime("%b %d, %Y", strtotime($lastlogin));
		}

		if($u == $log_username && $user_ok == true)  // show edit profile link only if this is your profile
		{
			echo'<a href="/editprofile.php">Edit Profile</a>';
			echo'<br>';
			echo'<a href="/logout.php">Logout</a>';
			echo'<br>';
			echo'<a href="/createpost.php">Create Post</a> <br>';
			echo'<a href="/browse.php">Browse</a> <br><br><br>';
		}
		
		// showing image
		 $imgsql = "SELECT image, imagename FROM users WHERE username='$log_username'";
		 $imgquery = mysqli_query($db_conx, $imgsql);
		 $imgresult = mysqli_fetch_array($imgquery);
		 $encode = base64_encode( $imgresult['image'] );
		  echo '<img src="data:image/jpeg;base64,'.$encode.'" height="200" width="200" border="4"/>';
	?>
	</div>
</form>


<div id="pageMiddle">
<form name = "deletepost" method = "POST">
  <h1><?php echo $u; ?>'s Profile</h1>
  <p>Join Date: <?php echo $joindate; ?></p>
  <p>Last Session: <?php echo $lastsession; ?></p>

 <?php

 //showing your posts
 $sql2 = "SELECT * FROM posts WHERE user='$log_username'";
 $query2 = mysqli_query($db_conx, $sql2);
 $count = mysqli_num_rows($query2);
 if ($count > 0)
 {
	 echo '<h3>Current Posts</h3>';
	 while($row = mysqli_fetch_array($query2, MYSQLI_ASSOC)) {
		//echo $row["title"] ." ".$row["id"];
		$linkaddress = "post.php?p=".$row["id"];
		$title = $row["title"];
		$date = $row["createtime"];
		$platform = $row["platform"];
		//echo $linkaddress."\n";
	?>
		<input name="checkbox[]" type="checkbox" value="<?php echo $row['id'];?>"></td>
	<?php
		echo "<a href='".$linkaddress."'>".$title."</a> | ".$platform. " | ".$date."<br><br>";
		//echo "\n";
	}

 
	 ?>
	 <input name="delete" type="submit" value="Delete">
	 <?php
	 if(isset($_POST['delete']))
	{
		$checkbox = $_POST['checkbox'];

		for($i=0;$i<count($checkbox);$i++){

		$deleteID = $checkbox[$i];
		$sql3 = "DELETE FROM posts WHERE id='$deleteID'";
		$result = mysqli_query($db_conx, $sql3);

		}

		if($result){
		echo "<meta http-equiv=\"refresh\" content=\"0;URL=user.php\">";
		}
	}
}
else 
	echo '<br><h3>No Current Swap Posts</h3>Click the link at the top of the page to create a swap post!<br>';
 ?>
 <?php
		// showing your personal wish list
		$wishsql = "SELECT * FROM posts WHERE user='$log_username'";
		$wishquery = mysqli_query($db_conx, $sql2);
		$wishrowcount = mysqli_num_rows($swapresult);
		if ($wishrowcount > 0)
		{
			echo '<h2>My Wish List</h2>';
			echo '</form>';
			echo '<table width= "100%" bgcolor= "#FFFFFF" cellpadding="2" cellspacing="2" border="1"';
			echo '<thead>
			<tr>
			<th>Title</th>
			<th>System</th>
			</tr>
			</thead>';
			while($row = mysql_fetch_array($wishresult))
			{
				echo "<tr><td>" . $row['title'] . "</td><td>" . $row['system'] . "</td></tr>";
			}
			echo "</table>";
		}
		else
			echo '<br><h3>No Current Wish Posts</h3>Click the link at the top of the page to create a wish post!<br>';
 
 ?>
 
 </form>
</div>

			<div id="footer">
				<a href="about.html">About</a>
				<a href="contact.html">Contact</a>
				<a href="terms.html">Terms</a>
			</div>
		</div> <!-- end wrapper -->
</body>
</html>